# CACTI
CACTI (formerly CTCSU) is GUI-driven tool used to "code" and study the delivery of MI (Motivational Interviewing). 
MI and CACTI were initially developed at the University of New Mexico Center on Alcoholism, Substance Abuse, and Addictions (CASAA).

This derivative version has been created primarily to address the need to run on OSX. It has also been extensively tested on Windows 10 and Debian distributions.
The majority of the original code has been entirely replaced such that JavaFX replaces Swing, AWT, and Javazoom.
