package org.mono.util;

import java.io.File;

import it.sauronsoftware.jave.AudioAttributes;
import it.sauronsoftware.jave.Encoder;
import it.sauronsoftware.jave.EncoderException;
import it.sauronsoftware.jave.EncodingAttributes;

public class AudioConversion {
	/**
	 * A method to specifically convert various audio types to WAV format
	 * @param source The source file, must be a WMA or MP3 audio file
	 * @return A reference to the converted file
	 */
	public static File toWAV(File source) {
		String extension = source.getAbsolutePath().substring(source.getAbsolutePath().lastIndexOf("."));
		String path = source.getAbsolutePath().substring(0, source.getAbsolutePath().lastIndexOf("."));
		if (extension.equals(".wma") || extension.equals(".mp3")) {
			File target = new File(path + ".wav");
			AudioAttributes audio = new AudioAttributes();
			audio.setCodec("pcm_s16le");
			EncodingAttributes attrs = new EncodingAttributes();
			attrs.setFormat("wav");
			attrs.setAudioAttributes(audio);
			Encoder encoder = new Encoder();
			try {
				encoder.encode(source, target, attrs);
			} catch (EncoderException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return target;
		} else {
			throw new IllegalArgumentException("Wrong file format: "+extension);
		}
	}
}
